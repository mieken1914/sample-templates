phonegap-template
=================

Template www phonegap folder with jQuery Mobile, Flat UI, and FastClick to remove 300ms delay on clicks.

Pre-Requisites
=============

* Have Phonegap / Cordova installed and setup in your environment.
* 

Using Template
==============

* Download or clone the repo.
* Create a new Phonegap 3.x project from the commmand line.
* Dump this repo into the www folder of your new PhoneGap project.

