var path = require('path');

module.exports = {
    dirname: path.join(__dirname,'template_src')
};